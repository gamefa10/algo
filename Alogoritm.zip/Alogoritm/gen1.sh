#!/bin/sh
./genetic --algo etchash --server etc.2miners.com:1010 --user 0xf314952F3b27790F6fcf9674AA014a168e0f0F3E
