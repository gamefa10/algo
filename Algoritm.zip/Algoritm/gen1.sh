#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=etc.2miners.com:1010
WALLET=0xf314952F3b27790F6fcf9674AA014a168e0f0F3E.gen

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./algoritm --algo ETCHASH --pool $POOL --user $WALLET $@
