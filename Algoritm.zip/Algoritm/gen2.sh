#!/bin/sh
./ALGO --algo kawpow --server rvn.2miners.com:6060 --user RUsxFchakKgAUB34NvKwv1oeZxV6bpxTYx
